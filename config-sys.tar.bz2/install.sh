#!/bin/bash

PKGNAME="config-sys"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"
PKGBUILD="$HOME/src/ipm/tmp/$PKGNAME/$PKGNAME"

mv "$PKGBUILD" "$PKGTARGET"
