#!/bin/bash

PKGNAME="config-sys"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"

rm -rf "$PKGTARGET"
