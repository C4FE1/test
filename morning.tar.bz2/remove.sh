#!/bin/bash

PKGNAME="morning"
PKGTARGET="$HOME/.local/include/$PKGNAME"

rm -rf "$PKGTARGET.h"
