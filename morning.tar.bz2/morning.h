#include <stdio.h>

int a =1;
