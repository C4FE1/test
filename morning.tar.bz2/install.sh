#!/bin/bash

PKGNAME="morning"
PKGBUILD="$HOME/src/ipm/tmp/$PKGNAME/"
PKGTARGET="$HOME/.local/include/"

mv "$PKGBUILD$PKGNAME.h" "$PKGTARGET$PKGNAME.h"
