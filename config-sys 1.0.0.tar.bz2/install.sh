#!/bin/bash

PKGNAME="config-sys"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"

mv "$PKGNAME" "$PKGTARGET"
