#!/bin/bash

PKGNAME="good"
PKGBUILD="$HOME/src/ipm/tmp/$PKGNAME"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"

gcc -o "$PKGTARGET" "$PKGBUILD$PKGNAME.c"
