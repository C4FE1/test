#!/bin/bash

PKGNAME="good"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"

rm -rf "$PKGTARGET"
