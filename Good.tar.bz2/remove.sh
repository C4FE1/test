#!/bin/bash

PKGNAME="Good"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"

rm -rf "$PKGTARGET"
