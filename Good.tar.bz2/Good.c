#include "/home/cana/.local/include/morning.h"

int main(){
  if(a!=NULL){
    printf("Good Morning!\n");
  }else{
    printf("Erro Morning not present.\n");
  }
  return 0;
}
