#!/bin/bash

PKGNAME="Hello"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"

echo "$HOME"
rm -rf "$PKGTARGET" 
