#!/bin/bash

PKGNAME="Hello"
PKGTARGET="$HOME/.local/usr/bin/$PKGNAME"

rm -rf "$PKGTARGET" 
