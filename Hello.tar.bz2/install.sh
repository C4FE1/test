#!/bin/bash

PKGNAME="Hello"
PKGTARGET="$HOME/.local/usr/bin/"
PKGBUILD="$HOME/src/ipm/tmp/$PKGNAME/"

echo "Instalando $PKGNAME"

gcc -o "$PKGTARGET$PKGNAME" "$PKGBUILD$PKGNAME.c"

