#!/bin/bash

PKGTARGET="$HOME/.local/usr/bin/"
PKGBUILD="$HOME/src/ipm/tmp/$PKGNAME/"
PKGNAME="Hello"

echo "Instalando $PKGNAME"

gcc -o "$PKGTARGET$PKGNAME" "$PKGBUILD$PKGNAME.c"

