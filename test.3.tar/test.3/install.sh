#!/bin/bash
echo "Obrigado por executar"

gcc -o /home/cana/.local/usr/bin/Hello /home/cana/Sources/spm/unziped/test.3/pkg/Hello.c


