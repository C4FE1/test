#!/bin/bash
echo "Obrigado por executar"

mv /home/cana/Sources/spm/unziped/Hello /home/cana/.local/usr/bin/
