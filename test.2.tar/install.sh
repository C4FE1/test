#!/bin/bash
echo "Obrigado por executar\n"
