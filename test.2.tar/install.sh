#!/bin/bash
echo "Obrigado por executar" \n

mv Hello .local/usr/bin/
